# dmbiolib

Library of Python functions to be used in various projects.

Install from PyPI:
````
pip install dmbiolib
````
Full documentation: https://dmbiolib.readthedocs.io/

GitHub issues (bug reports, feature requests): https://github.com/damienmarsic/dmbiolib/issues/new/choose

[![dmbiolib documentation](https://img.shields.io/badge/dmbiolib-Documentation-yellow)](https://dmbiolib.readthedocs.io/)


